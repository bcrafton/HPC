Time Table
Problem Size	|	Time Taken
10^7			|	.42
10^8			|	2.37
10^9			|	20.77