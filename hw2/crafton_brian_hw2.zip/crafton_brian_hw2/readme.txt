Brian Crafton
HW2
This zip contains code for problem 1a, and 1b
output file contains the actual run through of the script
And hello_world_mp.bash contains the script